﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TDAmeritradeNet
{
    public class SnapshotResultsArgs
    {
        public RequestSourceType SourceType { get; set; }
        public List<L1QuoteSnapshot> Results { get; set; } 
    }

    public enum RequestSourceType
    {
        Timer,
        Manual
    }
}

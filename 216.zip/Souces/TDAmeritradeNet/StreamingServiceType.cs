﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TDAmeritradeNet
{
    public enum StreamingServiceType
    {
        HeartBeat,
        AccountActivity,
        StreamerServer,
        L1QuoteStreaming,
        L1QuoteSnapshot,
        L2NYSEBook,
        L2TotalViewL2,
        L2TotalViewAD,
        TimeSales,
        NYSE_Chart,
        NASDAQ_Chart,
        INDEX_Chart,
        News,
        //NewsHistory,
        NotDefined,
        Error,
        NotFound
    }
}

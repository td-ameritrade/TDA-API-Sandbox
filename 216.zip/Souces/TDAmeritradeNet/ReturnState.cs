﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TDAmeritradeNet
{
    public class ReturnState
    {
        public StreamingServiceType ObjectServiceType { get; set; }
        public object Content { get; set; }
    }
}

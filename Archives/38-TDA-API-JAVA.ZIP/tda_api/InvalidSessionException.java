

public class InvalidSessionException extends Exception
{
}
